<?php
	$_G['MYSQL']['LOCATION'] = 'localhost';
	$_G['MYSQL']['USERNAME'] = 'root';
	$_G['MYSQL']['PASSWORD'] = 'hadsky.com';
	$_G['MYSQL']['DATABASE'] = 'test';
	$_G['MYSQL']['CHARSET'] = 'set names utf8';
	$_G['MYSQL']['PREFIX'] = 'pk_';
	